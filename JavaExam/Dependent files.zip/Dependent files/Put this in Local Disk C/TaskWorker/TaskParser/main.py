import os

def read_users_txt(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    user_data = {'FNAME': lines[0].strip(),
                 'LNAME': lines[1].strip(),
                 'COLLEGE': lines[2].strip(),
                 'PROFILE': lines[3].strip(),
                 'GROUP': lines[4].strip()
                 }

    return user_data

def read_tasks_txt(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.read()

def read_java_classes(folder_path):
    java_files = [f for f in os.listdir(folder_path) if f.endswith('.java')]
    java_classes = []

    for java_file in java_files:
        with open(os.path.join(folder_path, java_file), 'r', encoding='utf-8') as f:
            class_content = f.read()
        java_classes.append((java_file, class_content))

    return java_classes

def generate_input_txt(user_data, task_content, java_classes, output_file_path):
    with open(output_file_path, 'w', encoding='utf-8') as f:
        f.write(f"Nume Student: {user_data['FNAME']}\n")
        f.write(f"Prenume Student: {user_data['LNAME']}\n")
        f.write(f"Facultatea: {user_data['COLLEGE']}\n")
        f.write(f"Specializarea: {user_data['PROFILE']}\n")
        f.write(f"Grupa: {user_data['GROUP']}\n\n")

        f.write(task_content)
        f.write("\n\n")

        for class_name, class_content in java_classes:
            f.write(f"Class {class_name}:\n\n")
            f.write(class_content)
            f.write("\n\n")

if __name__ == "__main__":
    users_file = os.path.expandvars('%APPDATA%\\users.txt')
    tasks_file = 'C:\\TaskWorker\\TaskCreator\\tasks.txt'
    java_folder = os.path.expanduser('~\\Desktop\\JavaExam\\JavaExam\\src')
    output_file = 'C:\\TaskWorker\\TaskEvaluator\\input.txt'

    user_data = read_users_txt(users_file)
    task_content = read_tasks_txt(tasks_file)
    java_classes = read_java_classes(java_folder)

    generate_input_txt(user_data, task_content, java_classes, output_file)