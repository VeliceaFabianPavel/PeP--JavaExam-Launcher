import openai
import os


# Open the text file for reading with utf-8 encoding
with open("script.txt", "r", encoding="utf-8") as file:
    # Read the content of the file
    contentOfScript = file.read()


# Open the text file for reading with utf-8 encoding
with open("input.txt", "r", encoding="utf-8") as file:
    # Read the content of the file
    contentOfInput = file.read()

openai.api_key = "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"

completion = openai.ChatCompletion.create(
  model="gpt-4",
  messages=[
      {"role": "user", "content": f"{contentOfScript}"},
      {"role": "assistant", "content": "OK!"},
      {"role": "user", "content": f"{contentOfInput}"}
  ]
)

# Write the content to a new file called "result.txt"
with open("result.txt", "w", encoding="utf-8") as output_file:
 output_file.write(completion.choices[0].message.content)