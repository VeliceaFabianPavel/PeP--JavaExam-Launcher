import os
import openai
# -*- coding: utf-8 -*-
# -*- coding: latin-1 -*-
# -*- coding: utf-8 -*-

openai.api_key = "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"

response = openai.ChatCompletion.create(
  model="gpt-4",
  messages=[
    {
      "role": "user",
      "content": "I will need you to act as a Computer Science professor that will evaluate a Java exam based on a exam structure:\nI will give you the exam structure, how you should generate the further tasks and a csv file header, along with a few example datas\nAll right:\nThe exam structure:\n\nThere will be 4 tasks and a csv file:\nThe exam tasks will be in Romanian Language!!\nIf a student solves correctly the 1'st task, based on his code and the output result his grade will be 5\nHowever if he solves correctly the 2'nd task too, based on his code and the output result, his grade will be 6\nHowever if he solves correctly the 3'rd task too, based on his code and the output result, his grade will be 8\nAnd lastly, if he solves correctly the 4'th task too, based on his code and the output result, his grade will be 10\n\nIf none of these were correct, the default grade will be 4\n\nDown below I will give you an example on how you should generate tasks and a csv file\n\nThe exam tasks and csv:\n0. Domain: Flights\n1. CSV File\n        1.1 Filename: flights.csv\n        1.2 CSV file header, so you will know with what kind of data will be the CSV file populated:\n                 ID,COMPANIE,PLECARE,SOSIRE,NR_PASAGERI,NR_LOCURI,PRET,STATUS\n\t  1.3 CSV file populated:\n\t\t     \"\nID,COMPANIE,PLECARE,SOSIRE,NR_PASAGERI,NR_LOCURI,PRET,STATUS\n1,WIZZ-AIR,2023-07-02,2023-07-02,150,180,200.00,Sosit\n2,DAN-AIR,2023-07-03,2023-07-03,100,120,150.00,Plecat\n3,TAROM,2023-07-04,2023-07-04,180,150,250.00,Intarziat\n4,RYAN-AIR,2023-07-05,2023-07-05,130,150,180.00,Plecat\n5,EUROWINGS,2023-07-06,2023-07-06,180,200,230.00,Sosit\n6,WIZZ-AIR,2023-07-07,2023-07-07,200,180,140.00,Intarziat\n7,DAN-AIR,2023-07-08,2023-07-08,160,140,190.00,Sosit\n8,TAROM,2023-07-09,2023-07-09,200,220,220.00,Plecat\n9,RYAN-AIR,2023-07-10,2023-07-10,140,120,170.00,Intarziat\n10,EUROWINGS,2023-07-11,2023-07-11,210,200,250.00,Plecat\n11,WIZZ-AIR,2023-07-12,2023-07-12,180,150,180.00,Sosit\n12,DAN-AIR,2023-07-13,2023-07-13,190,200,230.00,Intarziat\n13,TAROM,2023-07-14,2023-07-14,180,160,200.00,Plecat\n14,RYAN-AIR,2023-07-15,2023-07-15,150,120,150.00,Sosit\n15,EUROWINGS,2023-07-16,2023-07-16,230,220,250.00,Intarziat\n16,WIZZ-AIR,2023-07-17,2023-07-17,170,160,190.00,Plecat\n17,DAN-AIR,2023-07-18,2023-07-18,160,140,170.00,Sosit\n18,TAROM,2023-07-19,2023-07-19,200,190,220.00,Intarziat\n19,RYAN-AIR,2023-07-20,2023-07-20,230,220,250.00,Plecat\n20,EUROWINGS,2023-07-21,2023-07-21,180,150,180.00,Sosit\n21,WIZZ-AIR,2023-07-22,2023-07-22,220,200,220.00,Intarziat\n22,DAN-AIR,2023-07-23,2023-07-23,200,180,200.00,Plecat\n23,TAROM,2023-07-24,2023-07-24,150,120,150.00,Sosit\n24,RYAN-AIR,2023-07-25,2023-07-25,200,180,230.00,Intarziat\n25,EUROWINGS,2023-07-26,2023-07-26,190,160,190.00,Plecat\n26,WIZZ-AIR,2023-07-27,2023-07-27,220,200,250.00,Sosit\n27,DAN-AIR,2023-07-28,2023-07-28,180,150,180.00,Intarziat\n28,TAROM,2023-07-29,2023-07-29,140,120,140.00,Plecat\n29,RYAN-AIR,2023-07-30,2023-07-30,200,220,200.00,Sosit\n30,EUROWINGS,2023-07-31,2023-07-31,170,150,190.00,Intarziat\n\t\t     \"\n2. Exam Tasks:\nTask 1: Din fisierul CSV cititi o lista de zboruri, avand grija ca \"NR_PASAGERI\" sa nu fie mai mare decat \"NR_LOCURI\".\nTask 2: Afisati lista citita anterior pe ecran, avand grija sa afisezi doar zborurile companiei \"WIZZ-AIR\".\nTask 3: Sortati lista zborurilor afisata anterior pe ecran dupa \"PRET\", descrescator\nTask 4: Grupati intr-o colectie zborurile procesate anterior, dupa \"STATUS\".\n\n3.Overview:\nAveti o lista de zboruri si doriti sa o manipulati in functie de preferintele dvs. de zbor. Creati o clasa Zboruri.java in care sa adaugati fiecare camp din fisierul csv folosind tipuri de data corecte pentru fiecare zbor si sa respectati cele 4 cerinte impuse!\n \nKeep in mind that this is just an example, and the result should not contain any fields from the example above. Use the model above just as an example\nTry your best to modify the tasks, respecting the structure below and the example above. I mean, try to not make the tasks sounds robotic. As you saw in the previous example, at the first task, the students needed to read the list on the screen (Which is an mandatory first task) but I also added something more (to read only in a certain condition)\n\nThe domain, is random (up to your choice), and should be related to the csv file.\nAfter sending this, I want you to answer with:\n\"\nDomain: {Random Domain. It's up to your choice what you select (traveling,gardening, etc.... anything)}\nCSV file:{Filename.csv}\n\n<csv>\n{Header. Should be related to the domain, just like the header from the example above is related to the domain}\n{A minimum of 10 and a maximum of 30 entries related to the header and the domain above}\n</csv>\n\nTask 1:  {Fill here accordingly, based on the example above, and the domain selected by you} --Reading task--\nTask 2: {Fill here accordingly, based on the example above, and the domain selected by you}--Printing task--\nTask 3: {Fill here accordingly, based on the example above, and the domain selected by you}--Sorting task--\nTask 4: {Fill here accordingly, based on the example above, and the domain selected by you}--Grouping in colection task--\nOverview: {A suggestive overview, related to the domain and the tasks, similar with the one presented above. Keep in mind that this overview will not disclose informations above the tasks}\n\"\n"
    },
    {
      "role": "user",
      "content": "Also, please do not include the \" character when generating and respect the format for the csv file, and that means to use the <csv> ... </csv> when generating the file. Those are crucial mentions, because I am using a program that extract that csv from those <csv> </csv>. Also do not forget that the tasks you will generate will be in ROMANIAN language!"
    }
  ],
  temperature=1.10,
  max_tokens=1800,
)
# Get the response text and strip any leading/trailing spaces
response_text = response.choices[0].message.content.strip()
# Check if the response text is not empty
if response_text:
    tasks_file_path = os.path.join("C:\\TaskWorker\\TaskCreator", 'tasks.txt')

    # Save the response to the tasks.txt file
    with open(tasks_file_path, 'w', encoding='utf-8') as tasks_file:
        tasks_file.write(response_text)

    print(f"Response saved to {tasks_file_path}")
else:
    print("The response is empty or contains only spaces.")